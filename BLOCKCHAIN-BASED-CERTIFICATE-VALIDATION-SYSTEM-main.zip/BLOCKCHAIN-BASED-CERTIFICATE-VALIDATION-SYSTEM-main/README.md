Tools
Frontend: 
HTML (Hyper Text Markup Language)
CSS (Cascading Style Sheets)
JS (JavaScript)

Backend: 
SMTP (Simple Mail Transfer Protocol)
PHP: Server-side scripting language.
SQL (Structured Query Language)

OS (Zorin)
Vmware-https://www.vmware.com/in/products/workstation-pro/workstation-pro-evaluation.html
